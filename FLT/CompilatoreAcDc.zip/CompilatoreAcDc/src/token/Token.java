package token;

public class Token {

	private int riga;
	private TokenType tipo;
	private String val;
	
	public Token(TokenType tipo, int riga, String val) {
	}
	
	public Token(TokenType tipo, int riga) {
	}

    // Getters per i campi
    
	public String toString() {
		return null;
	}

     

}
