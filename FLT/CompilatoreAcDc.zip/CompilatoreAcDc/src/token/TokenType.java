package token;

public enum TokenType {
	
	EOF;
}
