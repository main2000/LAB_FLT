package scanner;

public class LexicalException extends Exception {
	
	// Costruttori
	

}
